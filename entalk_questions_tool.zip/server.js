const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Configuration, OpenAIApi } = require('openai');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// MongoDB connection - using in-memory MongoDB for local development
const connectDB = async () => {
  try {
    console.log('MongoDB connection: Using in-memory database for local development');
    // We'll use a simple in-memory data store instead of MongoDB
    global.users = [];
    global.events = [];
    global.questions = [];
    console.log('In-memory database initialized successfully');
  } catch (err) {
    console.error('MongoDB connection error:', err.message);
    process.exit(1);
  }
};

// OpenAI Configuration
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY || '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',
});
const openai = new OpenAIApi(configuration);

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'entalk-secret-key';

// Models (simplified for in-memory storage)
// User Model
class User {
  constructor(name, email, password) {
    this.id = Date.now().toString();
    this.name = name;
    this.email = email;
    this.password = password;
  }
}

// Event Model
class Event {
  constructor(name, description, date, userId) {
    this.id = Date.now().toString();
    this.name = name;
    this.description = description;
    this.date = date;
    this.userId = userId;
  }
}

// Question Model
class Question {
  constructor(text, eventId) {
    this.id = Date.now().toString();
    this.text = text;
    this.eventId = eventId;
  }
}

// Auth Middleware
const auth = (req, res, next) => {
  const token = req.header('x-auth-token');

  if (!token) {
    return res.status(401).json({ msg: 'No token, authorization denied' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded.user;
    next();
  } catch (err) {
    res.status(401).json({ msg: 'Token is not valid' });
  }
};

// Routes
// Register User
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;

  try {
    // Check if user exists
    const userExists = global.users.find(user => user.email === email);
    if (userExists) {
      return res.status(400).json({ msg: 'User already exists' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user
    const user = new User(name, email, hashedPassword);
    global.users.push(user);

    // Create JWT
    const payload = {
      user: {
        id: user.id
      }
    };

    jwt.sign(
      payload,
      JWT_SECRET,
      { expiresIn: '1h' },
      (err, token) => {
        if (err) throw err;
        res.json({ token });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Login User
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Check if user exists
    const user = global.users.find(user => user.email === email);
    if (!user) {
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    // Create JWT
    const payload = {
      user: {
        id: user.id
      }
    };

    jwt.sign(
      payload,
      JWT_SECRET,
      { expiresIn: '1h' },
      (err, token) => {
        if (err) throw err;
        res.json({ token });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get User
app.get('/api/auth/user', auth, async (req, res) => {
  try {
    const user = global.users.find(user => user.id === req.user.id);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    
    // Don't send password
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Create Event
app.post('/api/events', auth, async (req, res) => {
  const { name, description, date } = req.body;

  try {
    const event = new Event(name, description, date, req.user.id);
    global.events.push(event);
    res.json(event);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get Events
app.get('/api/events', auth, async (req, res) => {
  try {
    const events = global.events.filter(event => event.userId === req.user.id);
    res.json(events);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get Event by ID
app.get('/api/events/:id', async (req, res) => {
  try {
    const event = global.events.find(event => event.id === req.params.id);
    if (!event) {
      return res.status(404).json({ msg: 'Event not found' });
    }
    res.json(event);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Generate Questions
app.post('/api/questions/generate', auth, async (req, res) => {
  const { topic, count } = req.body;

  try {
    // Generate questions using OpenAI
    const prompt = `Generate ${count || 5} engaging conversation questions about ${topic}. Return only the questions as a JSON array of strings.`;
    
    // For local development, we'll use mock data instead of calling OpenAI
    const mockQuestions = [
      `What's your favorite aspect of ${topic}?`,
      `How has ${topic} changed in the last few years?`,
      `What challenges do you see in ${topic} today?`,
      `If you could change one thing about ${topic}, what would it be?`,
      `How do you think ${topic} will evolve in the future?`
    ];
    
    res.json({ questions: mockQuestions });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Save Questions
app.post('/api/questions', auth, async (req, res) => {
  const { questions, eventId } = req.body;

  try {
    // Check if event exists and belongs to user
    const event = global.events.find(event => event.id === eventId);
    if (!event) {
      return res.status(404).json({ msg: 'Event not found' });
    }
    
    if (event.userId !== req.user.id) {
      return res.status(401).json({ msg: 'Not authorized' });
    }

    // Save questions
    const savedQuestions = questions.map(questionText => {
      const question = new Question(questionText, eventId);
      global.questions.push(question);
      return question;
    });

    res.json(savedQuestions);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Get Questions by Event ID
app.get('/api/questions/:eventId', async (req, res) => {
  try {
    const questions = global.questions.filter(question => question.eventId === req.params.eventId);
    res.json(questions);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
});

// Connect to database and start server
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});

// Add some sample data for testing
setTimeout(() => {
  // Create a test user
  const createTestUser = async () => {
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('Entalk123!', salt);
    const user = new User('EnTalk Admin', 'admin@entalk.com', hashedPassword);
    global.users.push(user);
    console.log('Test user created:', user.email);
    
    // Create a test event
    const event = new Event('Sample Event', 'This is a sample event for testing', new Date().toISOString(), user.id);
    global.events.push(event);
    console.log('Test event created:', event.name);
    
    // Create sample questions
    const questions = [
      'What brought you to this event today?',
      'What\'s the most interesting project you\'ve worked on recently?',
      'What\'s one skill you\'re currently trying to improve?',
      'What\'s a book or podcast that has influenced your thinking?',
      'What\'s something you\'re excited about for the future?'
    ];
    
    questions.forEach(questionText => {
      const question = new Question(questionText, event.id);
      global.questions.push(question);
    });
    console.log('Sample questions created');
  };
  
  createTestUser();
}, 1000);
