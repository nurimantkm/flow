# EnTalk Questions Tool - Documentation

## Overview
This document provides instructions for setting up and using the EnTalk Questions Tool, a web application for creating events and generating conversation questions for participants.

## Local Development Setup

### Prerequisites
- Node.js (v14 or higher)
- npm (v6 or higher)

### Installation Steps
1. Clone or download the project files to your local machine
2. Navigate to the project directory
3. Install dependencies:
   ```
   npm install
   ```
4. Start the server:
   ```
   npm start
   ```
5. Access the application at: http://localhost:5000

## Features

### User Authentication
- Register a new account
- Login with existing credentials
- Secure authentication using JWT tokens

### Event Management
- Create new events with name, description, and date
- View all your created events
- Generate conversation questions for events

### Question Generation
- Generate engaging conversation questions based on topics
- Save questions to specific events
- Share participant links for events

### Participant Experience
- Mobile-friendly swipeable question cards
- No login required for participants
- Simple, intuitive interface

## API Endpoints

### Authentication
- POST `/api/auth/register` - Register a new user
- POST `/api/auth/login` - Login a user
- GET `/api/auth/user` - Get current user info

### Events
- GET `/api/events` - Get all events for current user
- POST `/api/events` - Create a new event
- GET `/api/events/:id` - Get a specific event

### Questions
- POST `/api/questions/generate` - Generate questions based on topic
- POST `/api/questions` - Save questions to an event
- GET `/api/questions/:eventId` - Get questions for an event

## Technical Details

### Architecture
- Frontend: HTML, CSS, JavaScript with Bootstrap 5
- Backend: Node.js with Express
- Database: In-memory data store (for local development)
- Authentication: JWT tokens

### Data Models
- User: name, email, password
- Event: name, description, date, userId
- Question: text, eventId

## Troubleshooting

### Common Issues
- If you encounter CORS issues, ensure the frontend is accessing the correct API URL
- If authentication fails, check that your JWT token is being properly stored and sent
- If questions don't appear for participants, verify the event ID in the URL

### Support
For additional support or questions, please contact the development team.
