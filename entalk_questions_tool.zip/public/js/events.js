// Events page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the events page
    if (window.location.pathname.includes('events.html')) {
        // Require authentication
        requireAuth();
        
        // Load events
        loadEvents();
        
        // Setup event creation
        setupEventCreation();
        
        // Setup question generation
        setupQuestionGeneration();
    }
});

// Load user's events
async function loadEvents() {
    const eventsContainer = document.getElementById('events-container');
    
    try {
        const events = await apiRequest('/events');
        
        if (events.length === 0) {
            eventsContainer.innerHTML = `
                <div class="col-12 text-center py-5">
                    <p>You don't have any events yet. Create your first event to get started!</p>
                </div>
            `;
            return;
        }
        
        let eventsHTML = '';
        
        events.forEach(event => {
            const date = new Date(event.date).toLocaleDateString();
            
            eventsHTML += `
                <div class="col-md-4 mb-4">
                    <div class="card event-card h-100">
                        <div class="card-body">
                            <h5 class="card-title">${event.name}</h5>
                            <h6 class="card-subtitle mb-2 text-muted">${date}</h6>
                            <p class="card-text">${event.description}</p>
                        </div>
                        <div class="card-footer bg-white border-top-0">
                            <button class="btn btn-outline-primary btn-sm me-2 view-questions-btn" data-event-id="${event.id}">
                                View Questions
                            </button>
                            <button class="btn btn-primary btn-sm generate-questions-btn" data-event-id="${event.id}" data-bs-toggle="modal" data-bs-target="#generateQuestionsModal">
                                Generate Questions
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        eventsContainer.innerHTML = eventsHTML;
        
        // Add event listeners to buttons
        document.querySelectorAll('.view-questions-btn').forEach(button => {
            button.addEventListener('click', function() {
                const eventId = this.getAttribute('data-event-id');
                viewEventQuestions(eventId);
            });
        });
        
        document.querySelectorAll('.generate-questions-btn').forEach(button => {
            button.addEventListener('click', function() {
                const eventId = this.getAttribute('data-event-id');
                document.getElementById('event-id').value = eventId;
            });
        });
    } catch (error) {
        eventsContainer.innerHTML = `
            <div class="col-12 text-center py-5">
                <div class="alert alert-danger">
                    Failed to load events. Please try again.
                </div>
            </div>
        `;
        console.error('Error loading events:', error);
    }
}

// Setup event creation
function setupEventCreation() {
    const createEventBtn = document.getElementById('create-event-btn');
    
    createEventBtn.addEventListener('click', async function() {
        const name = document.getElementById('event-name').value;
        const description = document.getElementById('event-description').value;
        const date = document.getElementById('event-date').value;
        
        if (!name || !description || !date) {
            showAlert('Please fill in all fields');
            return;
        }
        
        try {
            await apiRequest('/events', 'POST', { name, description, date });
            
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('createEventModal'));
            modal.hide();
            
            // Show success message
            showAlert('Event created successfully!', 'success');
            
            // Reload events
            loadEvents();
            
            // Clear form
            document.getElementById('create-event-form').reset();
        } catch (error) {
            showAlert(error.message || 'Failed to create event');
        }
    });
}

// Setup question generation
function setupQuestionGeneration() {
    const generateBtn = document.getElementById('generate-btn');
    const saveQuestionsBtn = document.getElementById('save-questions-btn');
    
    generateBtn.addEventListener('click', async function() {
        const eventId = document.getElementById('event-id').value;
        const topic = document.getElementById('topic').value;
        const count = document.getElementById('question-count').value;
        
        if (!topic) {
            showAlert('Please enter a topic');
            return;
        }
        
        try {
            generateBtn.disabled = true;
            generateBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating...';
            
            const data = await apiRequest('/questions/generate', 'POST', { topic, count });
            
            // Display generated questions
            const questionsList = document.getElementById('questions-list');
            questionsList.innerHTML = '';
            
            data.questions.forEach(question => {
                const li = document.createElement('li');
                li.className = 'list-group-item';
                li.textContent = question;
                questionsList.appendChild(li);
            });
            
            document.getElementById('generated-questions').classList.remove('d-none');
            saveQuestionsBtn.classList.remove('d-none');
            generateBtn.innerHTML = 'Regenerate';
            generateBtn.disabled = false;
            
            // Store questions in a data attribute
            saveQuestionsBtn.setAttribute('data-questions', JSON.stringify(data.questions));
        } catch (error) {
            showAlert(error.message || 'Failed to generate questions');
            generateBtn.innerHTML = 'Generate';
            generateBtn.disabled = false;
        }
    });
    
    saveQuestionsBtn.addEventListener('click', async function() {
        const eventId = document.getElementById('event-id').value;
        const questions = JSON.parse(this.getAttribute('data-questions'));
        
        try {
            saveQuestionsBtn.disabled = true;
            saveQuestionsBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
            
            await apiRequest('/questions', 'POST', { questions, eventId });
            
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('generateQuestionsModal'));
            modal.hide();
            
            // Show success message
            showAlert('Questions saved successfully!', 'success');
            
            // Reset form and UI
            document.getElementById('generate-questions-form').reset();
            document.getElementById('generated-questions').classList.add('d-none');
            saveQuestionsBtn.classList.add('d-none');
            generateBtn.innerHTML = 'Generate';
            saveQuestionsBtn.innerHTML = 'Save Questions';
            saveQuestionsBtn.disabled = false;
        } catch (error) {
            showAlert(error.message || 'Failed to save questions');
            saveQuestionsBtn.innerHTML = 'Save Questions';
            saveQuestionsBtn.disabled = false;
        }
    });
}

// View event questions
async function viewEventQuestions(eventId) {
    const questionsListElement = document.getElementById('event-questions-list');
    questionsListElement.innerHTML = '<div class="text-center py-3"><div class="spinner-border text-primary" role="status"></div><p class="mt-2">Loading questions...</p></div>';
    
    // Show the modal
    const modal = new bootstrap.Modal(document.getElementById('viewQuestionsModal'));
    modal.show();
    
    try {
        const questions = await apiRequest(`/questions/${eventId}`);
        
        if (questions.length === 0) {
            questionsListElement.innerHTML = '<div class="alert alert-info">No questions found for this event. Generate some questions first!</div>';
            return;
        }
        
        questionsListElement.innerHTML = '';
        questions.forEach(question => {
            const li = document.createElement('li');
            li.className = 'list-group-item';
            li.textContent = question.text;
            questionsListElement.appendChild(li);
        });
        
        // Setup copy link button
        const copyLinkBtn = document.getElementById('copy-link-btn');
        copyLinkBtn.addEventListener('click', function() {
            const participantLink = `${window.location.origin}/participant.html?eventId=${eventId}`;
            navigator.clipboard.writeText(participantLink)
                .then(() => {
                    copyLinkBtn.textContent = 'Copied!';
                    setTimeout(() => {
                        copyLinkBtn.textContent = 'Copy Participant Link';
                    }, 2000);
                })
                .catch(err => {
                    console.error('Failed to copy link:', err);
                    showAlert('Failed to copy link. Please try again.');
                });
        });
    } catch (error) {
        questionsListElement.innerHTML = '<div class="alert alert-danger">Failed to load questions. Please try again.</div>';
        console.error('Error loading questions:', error);
    }
}
