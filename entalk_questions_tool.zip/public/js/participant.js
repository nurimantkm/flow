// Participant page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the participant page
    if (window.location.pathname.includes('participant.html')) {
        // Get event ID from URL
        const urlParams = new URLSearchParams(window.location.search);
        const eventId = urlParams.get('eventId');
        
        if (!eventId) {
            showError('No event ID provided. Please check your URL.');
            return;
        }
        
        // Load questions for the event
        loadEventQuestions(eventId);
    }
});

// Load questions for an event
async function loadEventQuestions(eventId) {
    try {
        const questions = await apiRequest(`/questions/${eventId}`);
        
        if (questions.length === 0) {
            showError('No questions found for this event.');
            return;
        }
        
        // Create question slides
        const questionsContainer = document.getElementById('questions-container');
        
        questions.forEach(question => {
            const slide = document.createElement('div');
            slide.className = 'swiper-slide';
            slide.innerHTML = `
                <div class="question-card">
                    <h2 class="question-text">${question.text}</h2>
                    <p class="swipe-instruction">Swipe left or right for more questions</p>
                </div>
            `;
            questionsContainer.appendChild(slide);
        });
        
        // Hide loading container
        document.getElementById('loading-container').style.display = 'none';
        
        // Show swiper container
        document.getElementById('swiper-container').style.display = 'block';
        
        // Initialize Swiper
        const swiper = new Swiper('.swiper', {
            effect: 'cards',
            grabCursor: true,
            centeredSlides: true,
            slidesPerView: 'auto',
            spaceBetween: 30
        });
    } catch (error) {
        showError('Failed to load questions. Please try again later.');
        console.error('Error loading questions:', error);
    }
}

// Show error message
function showError(message) {
    document.getElementById('loading-container').style.display = 'none';
    document.getElementById('error-container').style.display = 'flex';
    document.getElementById('error-message').textContent = message;
}
